| unit | passed | failed | aborted | seconds |
|---|---:|---:|---:|---:|
| unit/bitfield | 19 | 0 | 0 | 0 |
| unit/bitops | 62 | 0 | 0 | 18 |
| unit/dump | 13 | 0 | 0 | 15 |
| unit/expire | 60 | 0 | 0 | 5 |
| unit/functions | 93 | 0 | 0 | 1 |
| unit/geo | 65 | 0 | 0 | 14 |
| unit/hyperloglog | 20 | 1 | 0 | 50 |
| unit/info-command | 3 | 0 | 0 | 0 |
| unit/info-keysizes | 5 | 0 | 0 | 2 |
| unit/introspection-2 | 47 | 1 | 0 | 6 |
| unit/introspection | 41 | 0 | 0 | 1 |
| unit/keyspace | 45 | 0 | 0 | 0 |
| unit/latency-monitor | 10 | 1 | 0 | 1 |
| unit/lazyfree | 9 | 0 | 0 | 4 |
| unit/multi | 35 | 0 | 0 | 2 |
| unit/networking | 1 | 0 | 0 | 0 |
| unit/other | 17 | 0 | 0 | 1 |
| unit/pause | 18 | 0 | 0 | 1 |
| unit/protocol | 21 | 0 | 0 | 3 |
| unit/pubsub | 122 | 0 | 0 | 3 |
| unit/querybuf | 3 | 0 | 0 | 6 |
| unit/quit | 3 | 0 | 0 | 1 |
| unit/scan | 23 | 0 | 0 | 5 |
| unit/scripting | 218 | 1 | 0 | 15 |
| unit/slowlog | 20 | 0 | 0 | 0 |
| unit/sort | 19 | 0 | 0 | 3 |
| unit/tracking | 59 | 0 | 0 | 1 |
| unit/type/array | 124 | 0 | 0 | 1 |
| unit/type/hash-field-expire | 32 | 0 | 0 | 1 |
| unit/type/hash | 87 | 0 | 0 | 2 |
| unit/type/incr | 32 | 0 | 0 | 1 |
| unit/type/increx | 71 | 0 | 0 | 0 |
| unit/type/list-2 | 2 | 0 | 0 | 7 |
| unit/type/list-3 | 11 | 0 | 0 | 40 |
| unit/type/list-4 | 28 | 0 | 0 | 1 |
| unit/type/list | 257 | 0 | 0 | 12 |
| unit/type/set | 149 | 0 | 0 | 4 |
| unit/type/stream-cgroups | 154 | 0 | 0 | 12 |
| unit/type/stream | 191 | 0 | 0 | 26 |
| unit/type/string | 174 | 0 | 0 | 7 |
| unit/type/zset | 335 | 0 | 0 | 14 |
| **total** | **2698** | **4** | **0** | |

Redis test suite: 2698 passed, 4 failed, 0 units ended early.

<details><summary>Failed tests</summary>

```
[err]: Corrupted dense HyperLogLogs are detected: Wrong length in tests/unit/hyperloglog.tcl
[err]: TTL, TYPE and EXISTS do not alter the last access time of a key in tests/unit/introspection-2.tcl
[err]: LATENCY of expire events are correctly collected in tests/unit/latency-monitor.tcl
[err]: Verify Lua performs GC correctly after script loading in tests/unit/scripting.tcl
```
</details>
