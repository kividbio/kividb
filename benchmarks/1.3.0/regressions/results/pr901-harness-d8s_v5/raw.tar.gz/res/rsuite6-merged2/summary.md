| unit | passed | failed | aborted | seconds |
|---|---:|---:|---:|---:|
| unit/scripting | 218 | 1 | 0 | 19 |
| unit/functions | 93 | 0 | 0 | 3 |
| unit/multi | 35 | 0 | 0 | 3 |
| **total** | **346** | **1** | **0** | |

Redis test suite: 346 passed, 1 failed, 0 units ended early.

No failures outside scripts/redis_compat_known_failures.txt.

<details><summary>Failed tests</summary>

```
[err]: Verify Lua performs GC correctly after script loading in tests/unit/scripting.tcl
```
</details>
