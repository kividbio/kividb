#!/usr/bin/env bash
# Redis under callgrind: redis-server's setproctitle overwrites the environment
# vgdb needs, so callgrind_control cannot reach it. Instead two whole runs, one
# with the warm-up only and one with the warm-up and the N calls:
# Ir/call = (second - first) / N.
set -u
OUT=${OUT:-~/w/res/cgr}; mkdir -p $OUT
N=${N:-20000}
MODES=${MODES:-"script ret1 cad cfhist cfadd"}
TAGS=${TAGS:-"0 1"}
PORT=6396
run() { # mode tag withmain -> total Ir
  local m=$1 t=$2 main=$3
  rm -rf /tmp/cgr && mkdir -p /tmp/cgr && cd /tmp/cgr
  LD_PRELOAD=/tmp/plaincmp.so valgrind --tool=callgrind --vgdb=no --callgrind-out-file=/tmp/cgr/out \
    /opt/redis-8.10.2/src/redis-server --port $PORT --save "" --appendonly no > /tmp/cgr/log 2>&1 &
  local vg=$!
  for _ in $(seq 240); do redis-cli -p $PORT ping 2>/dev/null | grep -q PONG && break; sleep 0.5; done
  redis-cli -p $PORT --pipe < /tmp/cge-$m-$t-warm > /dev/null 2>&1
  [ $main = 1 ] && redis-cli -p $PORT --pipe < /tmp/cge-$m-$t > /tmp/cgr/pipe2 2>&1
  redis-cli -p $PORT shutdown nosave > /dev/null 2>&1
  wait $vg 2>/dev/null
  callgrind_annotate /tmp/cgr/out 2>/dev/null | grep -m1 "PROGRAM TOTALS" | tr -d "," | awk '{print $1}'
}
for m in $MODES; do for t in $TAGS; do
  a=$(run $m $t 0); b=$(run $m $t 1)
  echo "redis $m tag=$t Ir/call=$(( (b - a) / N )) $(grep -o 'errors: [0-9]*' /tmp/cgr/pipe2)" | tee -a $OUT/summary.txt
done; done
