#!/usr/bin/env bash
# #901 per-call script cost. Usage: bench901.sh <label> <binary|redis> [threads] [extra server args...]
# Server pinned to CPUs 0,1; clients on 2-7. Prints one line per workload to $OUT/<label>.txt.
set -u
L=$1; BIN=$2; T=${3:-2}; shift 3 || true
EXTRA="$*"
OUT=${OUT:-~/w/res/b}; mkdir -p $OUT
SB=~/w/bin/sb
D=${D:-10s}; W=${W:-3s}; C=${C:-64}
WL=${WL:-"script ret1 cad cfhist cfadd"}
PORT=6379
RC="redis-cli -p $PORT"
start() {
  if [ "$BIN" = redis ]; then
    taskset -c 0,1 /opt/redis-8.10.2/src/redis-server --port $PORT --save '' --appendonly no $EXTRA > $OUT/$L-server.log 2>&1 &
  else
    taskset -c 0,1 $BIN --port $PORT --threads $T --loglevel warning $EXTRA > $OUT/$L-server.log 2>&1 &
  fi
  SP=$!
  for _ in $(seq 100); do $RC ping 2>/dev/null | grep -q PONG && break; sleep 0.1; done
}
stopit() { $RC shutdown nosave >/dev/null 2>&1; sleep 0.5; kill $SP 2>/dev/null; wait $SP 2>/dev/null; }
ticks() { awk '{print $14+$15}' /proc/$SP/stat; }
evstat() { $RC info commandstats | tr -d '\r' | grep '^cmdstat_evalsha:' | sed 's/.*calls=\([0-9]*\),usec=[0-9]*,usec_per_call=\([0-9.]*\).*/calls=\1 upc=\2/'; $RC info stats | tr -d '\r' | grep -E '^scripts_(handed_to_runner|run_beside_others|run_alone_no_tag):' | tr '\n' ' '; }
start
for tg in "" -tag; do
  for m in $WL; do
    $RC flushall >/dev/null
    if [ $m = script ]; then rm -f /tmp/lgclock; taskset -c 2-7 $SB -mode preload $tg -clockfile /tmp/lgclock > /dev/null; fi
    $RC config resetstat >/dev/null
    r=$(taskset -c 2-7 $SB -mode $m $tg -c $C -d $D -w $W -pid $SP -clockfile /tmp/lgclock)
    echo "$L t=$T $m${tg} $r $(evstat | tr "\n" " ")" | tee -a $OUT/$L.txt
  done
  if [ "${BULL:-1}" = 1 ]; then
    P=bull; [ "$tg" = -tag ] && P='{bull}'
    $RC flushall >/dev/null; $RC config resetstat >/dev/null
    c0=$(ticks); a=$(cd ~/w/bull && PREFIX=$P taskset -c 2-7 node bullcpu.mjs add ${BN:-100000}); c1=$(ticks)
    e=$(evstat | tr '
' ' '); calls=$(echo "$e" | sed 's/calls=\([0-9]*\).*/\1/')
    echo "$L t=$T bulladd${tg} $a srvCPU=$(echo "scale=2; ($c1-$c0)*10000/$calls" | bc)us/call $e" | tee -a $OUT/$L.txt
    $RC config resetstat >/dev/null
    c0=$(ticks); a=$(cd ~/w/bull && PREFIX=$P taskset -c 2-7 node bullcpu.mjs process ${BN:-100000}); c1=$(ticks)
    e=$(evstat | tr '
' ' '); calls=$(echo "$e" | sed 's/calls=\([0-9]*\).*/\1/')
    echo "$L t=$T bullproc${tg} $a srvCPU=$(echo "scale=2; ($c1-$c0)*10000/$calls" | bc)us/call $e" | tee -a $OUT/$L.txt
  fi
done
stopit
echo DONE >> $OUT/$L.txt
