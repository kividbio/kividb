import redis, sys
r = redis.Redis(port=int(sys.argv[1]))
r.function_flush()
for i in range(50000):
    body = "#!lua name=gc%d\nredis.register_function('gc%d', function(KEYS, ARGV)\n --xxxxxxxxxx\nreturn %06d \nend)" % (i, i, i)
    r.function_load(body)
print(r.info("memory")["used_memory_vm_functions"])
