#!/usr/bin/env bash
# Instructions per script call under callgrind (CMP=plain), pipelined
# (redis-cli --pipe), one server thread.
#   cg2.sh <label>=<binary|redis> ...      MODES="script ret1 cad cfhist cfadd" TAGS="0 1"
set -u
OUT=${OUT:-~/w/res/cg}; mkdir -p $OUT
N=${N:-50000}
MODES=${MODES:-"script ret1 cad cfhist cfadd"}
TAGS=${TAGS:-"0 1"}
cc -O1 -fno-builtin -fno-tree-loop-distribute-patterns -shared -fPIC -o /tmp/plaincmp.so ~/w/br/scripts/perf/plaincmp.c || exit 1
cd /tmp
for m in $MODES; do for t in $TAGS; do
  tg=; [ $t = 1 ] && tg=-tag
  true || EMITMODE=$m ~/w/bin/sb -mode emit $tg -n $N -emitwarm 5000 -out /tmp/cge-$m-$t > /dev/null
done; done
PORT=6395
one() { # label mode tag cmd...
  local l=$1 m=$2 t=$3; shift 3
  rm -rf /tmp/cgp && mkdir -p /tmp/cgp
  LD_PRELOAD=/tmp/plaincmp.so valgrind --tool=callgrind --instr-atstart=no --callgrind-out-file=/tmp/cgp/out "$@" > /tmp/cgp/log 2>&1 &
  local vg=$!
  for _ in $(seq 240); do redis-cli -p $PORT ping 2>/dev/null | grep -q PONG && break; sleep 0.5; done
  redis-cli -p $PORT --pipe < /tmp/cge-$m-$t-warm > /tmp/cgp/pipe1 2>&1
  callgrind_control -i on > /dev/null 2>&1
  redis-cli -p $PORT --pipe < /tmp/cge-$m-$t > /tmp/cgp/pipe2 2>&1
  callgrind_control -i off > /dev/null 2>&1
  callgrind_control -d > /dev/null 2>&1
  redis-cli -p $PORT shutdown nosave > /dev/null 2>&1; sleep 1; kill -TERM $vg 2>/dev/null; wait $vg 2>/dev/null
  local f total
  f=$(ls -S /tmp/cgp/out* | head -1)
  total=$(callgrind_annotate "$f" 2>/dev/null | grep -m1 "PROGRAM TOTALS" | tr -d "," | awk '{print $1}')
  echo "$l $m tag=$t Ir/call=$(( ${total:-0} / N )) $(grep -o 'errors: [0-9]*' /tmp/cgp/pipe2)" | tee -a $OUT/summary.txt
  if [ "${PROFILE:-0}" = 1 ]; then
    callgrind_annotate --inclusive=yes "$f" 2>/dev/null | head -120 | cut -c1-200 > $OUT/$l-$m-$t-incl.txt
    callgrind_annotate --inclusive=no "$f" 2>/dev/null | head -70 | cut -c1-200 > $OUT/$l-$m-$t-self.txt
  fi
}
for spec in "$@"; do
  l=${spec%%=*}; b=${spec#*=}
  for m in $MODES; do for t in $TAGS; do
    if [ "$b" = redis ]; then
      one $l $m $t /opt/redis-8.10.2/src/redis-server --port $PORT --save "" --appendonly no
    else
      one $l $m $t $b --port $PORT --threads 1 --loglevel warning ${CGEXTRA:-}
    fi
  done; done
done
echo CG_DONE >> $OUT/summary.txt
