#!/usr/bin/env python3
"""#901 differential fuzz of script replies: random scripts from a grammar of
return shapes and redis.call results, sent as EVAL to several servers over
raw sockets (RESP2 and RESP3 clients), raw reply bytes compared.

  fuzz901.py <n> <seed> name=port [name=port ...]

The first server is the reference for "same" (the tree before the change);
every other server is compared with it byte for byte. Mismatches are written
to fuzz-mismatch-<name>.txt; a summary line per server is printed."""
import random
import socket
import sys


class Conn:
    def __init__(self, port, proto):
        self.s = socket.create_connection(("127.0.0.1", port))
        self.f = self.s.makefile("rb")
        if proto == 3:
            self.cmd("HELLO", "3")

    def send(self, *args):
        out = [b"*%d\r\n" % len(args)]
        for a in args:
            if isinstance(a, str):
                a = a.encode()
            elif isinstance(a, int):
                a = str(a).encode()
            out.append(b"$%d\r\n%s\r\n" % (len(a), a))
        self.s.sendall(b"".join(out))

    def read(self):
        """One whole reply, as its raw bytes (iteratively: replies nest 8,000 deep)."""
        parts = []
        pending = 1  # values still to read at the levels open
        stack = []
        while True:
            line = self.f.readline()
            if not line:
                raise RuntimeError("connection closed")
            parts.append(line)
            t = line[:1]
            children = 0
            if t in b"+-:_#,(":
                pass
            elif t in b"$=!":
                n = int(line[1:-2])
                if n >= 0:
                    parts.append(self.f.read(n + 2))
            elif t in b"*~%|>":
                n = int(line[1:-2])
                if n > 0:
                    children = n * 2 if t in b"%" else n
                if t == b"|":
                    children = n * 2 + 1
            else:
                raise RuntimeError("bad reply %r" % line)
            pending -= 1
            if children:
                stack.append(pending)
                pending = children
            while pending == 0 and stack:
                pending = stack.pop()
            if pending == 0 and not stack:
                return b"".join(parts)

    def cmd(self, *args):
        self.send(*args)
        return self.read()


R = random.Random()


def lua_str():
    choices = ['"a"', '""', '"hello world"', '"x\\0y"', '"line\\r\\nbreak"', '"\\255\\254"',
               '"' + "z" * R.randint(30, 60) + '"', '"ERR custom"', '"OK"', '"123"', "KEYS[1]", "ARGV[1]"]
    return R.choice(choices)


def lua_num():
    return R.choice(["0", "1", "-1", "42", "3.0", "3.7", "-2.5", "1e20", "-1e20", "2^53", "2^63",
                     "math.maxinteger", "math.mininteger", "0.5", "1/3", "7//2", "7/2", "0/0", "1/0",
                     "-1/0", "tonumber('10')", "#ARGV"])


CALLS = [
    "redis.call('get', KEYS[1])",
    "redis.call('get', 'fz:none')",
    "redis.call('set', KEYS[1], ARGV[1])",
    "redis.call('incr', 'fz:n')",
    "redis.call('lrange', 'fz:l', 0, -1)",
    "redis.call('hgetall', 'fz:h')",
    "redis.call('smembers', 'fz:s1')",
    "redis.call('zrange', 'fz:z', 0, -1, 'withscores')",
    "redis.call('ping')",
    "redis.call('exists', KEYS[1], 'fz:none')",
    "redis.call('type', 'fz:h')",
    "redis.pcall('incr', 'fz:str')",
    "redis.pcall('nosuchcommand')",
    "redis.pcall('lpush', 'fz:str', 'x')",
    "redis.call('mget', KEYS[1], 'fz:none', 'fz:str')",
    "redis.call('hmget', 'fz:h', 'a', 'zz')",
    "redis.status_reply('FINE')",
    "redis.error_reply('MYERR oops')",
    "redis.error_reply('plain')",
    "redis.call('time')[1] and 1",
    "redis.call('xadd', 'fz:x', '1-1', 'f', 'v') and 'x'",
    "redis.call('zscore', 'fz:z', 'a')",
    "redis.call('hget', 'fz:h', 'a')",
]


def expr(depth):
    r = R.random()
    if depth >= 4 or r < 0.35:
        return R.choice([
            "nil", "true", "false", lua_num(), lua_num(), lua_str(), lua_str(), R.choice(CALLS), R.choice(CALLS)])
    if r < 0.75:
        n = R.randint(0, 5)
        items = [expr(depth + 1) for _ in range(n)]
        return "{" + ", ".join(items) + "}"
    special = R.choice([
        "{ok=%s}" % lua_str(), "{ok='a\\nb\\rc'}", "{err=%s}" % lua_str(), "{err='WRONG thing'}",
        "{ok=1}", "{err=2}", "{double=%s}" % lua_num(), "{double='x'}", "{big_number='1234567890123456789'}",
        "{big_number=5}", "{map={a=%s}}" % expr(depth + 1), "{set={b=true}}", "{map=1}", "{set='x'}",
        "{verbatim_string={format='txt', string='hi'}}", "{verbatim_string={format=1, string='hi'}}",
        "{[1]={[1]={[1]=%s}}}" % expr(depth + 1), "{[2]=1}", "{1, nil, 3}", "{nil, 2}",
        "{x=1, %s}" % expr(depth + 1), "{%s, ok2='z'}" % expr(depth + 1),
    ])
    return special


PRELUDES = ["", "", "", "redis.setresp(3) ", "redis.setresp(2) "]
ODD = [
    "return undefined_global",
    "return type(gcinfo())",
    "return type(_G.redis)",
    "return type(getmetatable(_G).__index)",
    "return rawget(_G, 'redis')",
    "x = 1 return 1",
    "redis = 1 return 1",
    "return redis.call('get')",
    "return redis.call({})",
    "return redis.call()",
    "error('boom')",
    "error({err='TABLEERR x'})",
    "return redis.call('incr', 'fz:str')",
    "local t = {} for i = 1, 100 do t[i] = i end return t",
    "local t = {} t[1] = t return t",
    "local t = {} local c = t for i = 1, 100 do c[1] = {} c = c[1] end return t",
    "local t = {} local c = t for i = 1, 20 do c[1] = {i} c = c[1] end return t",
    "return pcall(function() return redis.call('incr', 'fz:str') end)",
    "return {pcall(error, 'x')}",
    "return KEYS",
    "return ARGV",
    "return {KEYS[1], ARGV[2], #KEYS, #ARGV}",
    "return cjson.encode({1,2})",
    "return cmsgpack.unpack(cmsgpack.pack({1,'a'}))",
    "return bit.band(7, 3)",
    "return struct.pack('>I2', 7)",
    "return string.format('%d', 3)",
    "return tostring(1e15)",
    "return math.huge",
    "return os.clock() >= 0",
]


def script():
    r = R.random()
    if r < 0.15:
        return R.choice(ODD)
    return R.choice(PRELUDES) + "return " + expr(0)


def setup(c):
    c.cmd("FLUSHALL")
    c.cmd("SET", "fz:str", "abc")
    c.cmd("RPUSH", "fz:l", "a", "b", "")
    c.cmd("HSET", "fz:h", "a", "1")
    c.cmd("SADD", "fz:s1", "m")
    c.cmd("ZADD", "fz:z", "1.5", "a")
    c.cmd("SET", "fz:n", "0")


def main():
    n, seed = int(sys.argv[1]), int(sys.argv[2])
    servers = [(a.split("=")[0], int(a.split("=")[1])) for a in sys.argv[3:]]
    R.seed(seed)
    cases = [(script(), R.choice([2, 3])) for _ in range(n)]
    conns = {}
    for name, port in servers:
        conns[name] = {2: Conn(port, 2), 3: Conn(port, 3)}
        setup(conns[name][2])
    ref = servers[0][0]
    diffs = {name: [] for name, _ in servers[1:]}
    for i, (src, proto) in enumerate(cases):
        replies = {}
        for name, _ in servers:
            c = conns[name][proto]
            # the same state for every server: counters and keys the script touches are reset
            conns[name][2].cmd("SET", "fz:n", "0")
            conns[name][2].cmd("DEL", "fz:k", "fz:x")
            replies[name] = c.cmd("EVAL", src, "1", "fz:k", "argv1", "argv2")
        for name, _ in servers[1:]:
            if replies[name] != replies[ref]:
                diffs[name].append((i, proto, src, replies[ref], replies[name]))
    for name, ds in diffs.items():
        with open("fuzz-mismatch-%s.txt" % name, "w") as f:
            for i, proto, src, a, b in ds:
                f.write("#%d resp%d %s\n  %s: %r\n  %s: %r\n" % (i, proto, src, ref, a, name, b))
        print("seed=%d cases=%d %s vs %s: %d differ" % (seed, n, name, ref, len(ds)))


if __name__ == "__main__":
    main()
