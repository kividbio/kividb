// #901: BullMQ 5.81.5 per-call cost. One phase per run; the caller reads the
// server's CPU before and after and INFO commandstats.
//   node bullcpu.mjs add <n>      queue.add x n, 50 in flight (addStandardJob, one EVALSHA each)
//   node bullcpu.mjs process <n>  worker, concurrency 50, until n jobs completed (moveToFinished
//                                 with fetch-next, one EVALSHA per job)
// PREFIX=bull (untagged) or PREFIX={bull} (every key under one hash tag).
import { Queue, Worker } from "bullmq";

const port = +(process.env.PORT || 6379);
const prefix = process.env.PREFIX || "bull";
const connection = { host: "127.0.0.1", port, maxRetriesPerRequest: null };
const mode = process.argv[2];
const n = +(process.argv[3] || 100000);
const payload = "x".repeat(1800);
const qname = "workflows";
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

if (mode === "add") {
  const q = new Queue(qname, { connection, prefix });
  await q.waitUntilReady();
  let next = 0;
  const t0 = Date.now();
  const one = async () => {
    while (next < n) {
      const i = next++;
      await q.add("step", { run: i, payload }, { removeOnComplete: false });
    }
  };
  await Promise.all(Array.from({ length: 50 }, one));
  const t = (Date.now() - t0) / 1000;
  console.log(`add jobs=${n} sec=${t.toFixed(2)} jobs/s=${(n / t).toFixed(0)}`);
  await q.close();
  process.exit(0);
}

if (mode === "process") {
  let done = 0;
  const w = new Worker(qname, async (j) => ({ ok: j.data.run }), { connection, prefix, concurrency: 50, autorun: false });
  w.on("completed", () => done++);
  w.on("failed", (j, e) => console.log("failed", e?.message));
  const t0 = Date.now();
  w.run();
  while (done < n && Date.now() - t0 < 600000) await sleep(5);
  const t = (Date.now() - t0) / 1000;
  console.log(`process completed=${done} sec=${t.toFixed(2)} jobs/s=${(done / t).toFixed(0)}`);
  await w.close(true);
  process.exit(0);
}
console.log("usage: add|process <n>");
