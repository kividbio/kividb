#!/usr/bin/env bash
# Replication and AOF after a randomized script workload: master (AOF on) and
# replica must end with the same DEBUG DIGEST, and so must the master
# restarted from its AOF.   repl901.sh <binary> <label>
set -u
B=$1; L=$2
D=~/w/res/repl/$L; rm -rf $D; mkdir -p $D/m $D/r
RC="redis-cli -p"
$B --port 6501 --dir $D/m --appendonly yes --appendfsync everysec --loglevel warning --threads 2 > $D/m.log 2>&1 & MP=$!
$B --port 6502 --dir $D/r --replicaof 127.0.0.1 6501 --loglevel warning --threads 2 > $D/r.log 2>&1 & RP=$!
sleep 2
python3 - <<'EOF'
import random, socket
R = random.Random(901)
def conn(port):
    s = socket.create_connection(("127.0.0.1", port)); return s, s.makefile("rb")
def send(s, *a):
    out = [b"*%d\r\n" % len(a)]
    for x in a:
        x = x if isinstance(x, bytes) else str(x).encode()
        out.append(b"$%d\r\n%s\r\n" % (len(x), x))
    s.sendall(b"".join(out))
def read(f):
    l = f.readline(); t = l[:1]
    if t in b"$":
        n = int(l[1:-2]); return l if n < 0 else l + f.read(n + 2)
    if t in b"*":
        n = int(l[1:-2]); return l + b"".join(read(f) for _ in range(max(n, 0)))
    return l
s, f = conn(6501)
scripts = [
 "redis.call('incrby', KEYS[1], ARGV[1]) return redis.call('get', KEYS[1])",
 "redis.call('zadd', KEYS[1], ARGV[1], ARGV[2]) redis.call('zremrangebyscore', KEYS[1], '-inf', ARGV[1] - 50) redis.call('expire', KEYS[1], 600) return redis.call('zcard', KEYS[1])",
 "if redis.call('get', KEYS[1]) == ARGV[1] then return redis.call('del', KEYS[1]) else return redis.call('set', KEYS[1], ARGV[1]) end",
 "redis.call('hset', KEYS[1], 'f' .. ARGV[1], ARGV[2]) redis.call('hincrbyfloat', KEYS[1], 'x', '1.5') return redis.call('hlen', KEYS[1])",
 "redis.call('lpush', KEYS[1], ARGV[2]) redis.call('ltrim', KEYS[1], 0, 9) redis.call('spop', KEYS[1] .. ':s') redis.call('sadd', KEYS[1] .. ':s', ARGV[1], ARGV[2]) return redis.call('llen', KEYS[1])",
 "redis.call('set', KEYS[1], ARGV[2], 'EX', 100) redis.call('pexpire', KEYS[1], 50000) return redis.call('incrbyfloat', KEYS[1] .. ':f', '0.25')",
 "redis.call('select', 1) redis.call('set', KEYS[1], ARGV[1]) redis.call('select', 0) return 1",
 "return redis.pcall('incr', 'no-number')",
 "redis.call('xadd', KEYS[1] .. ':x', '*', 'v', ARGV[1]) return redis.call('xlen', KEYS[1] .. ':x')",
]
send(s, "SET", "no-number", "abc"); read(f)
n = 0
for i in range(40000):
    src = R.choice(scripts)
    k = "k%d" % R.randrange(200)
    if R.random() < 0.3: k = "{t%d}%s" % (R.randrange(5), k)
    if R.random() < 0.05:
        send(s, "MULTI"); read(f); send(s, "EVAL", src, 1, k, R.randrange(1000), "v%d" % R.randrange(50)); read(f); send(s, "EXEC"); read(f)
    else:
        send(s, "EVAL", src, 1, k, R.randrange(1000), "v%d" % R.randrange(50)); read(f)
    n += 1
send(s, "WAIT", 1, 10000); print("wait:", read(f).strip(), "scripts:", n)
EOF
sleep 2
dm=$(~/venv/bin/python ~/w/dig.py 6501); dr=$(~/venv/bin/python ~/w/dig.py 6502)
echo "$L master=$dm replica=$dr $([ "$dm" = "$dr" ] && echo EQUAL || echo DIFFER) dbsize=$($RC 6501 dbsize)/$($RC 6502 dbsize)" | tee $D/result.txt
$RC 6501 shutdown > /dev/null 2>&1; wait $MP
$B --port 6501 --dir $D/m --appendonly yes --loglevel warning > $D/m2.log 2>&1 & MP=$!
sleep 3
da=$(~/venv/bin/python ~/w/dig.py 6501)
echo "$L aof-reload=$da $([ "$da" = "$dm" ] && echo EQUAL || echo DIFFER)" | tee -a $D/result.txt
$RC 6501 shutdown nosave > /dev/null 2>&1; $RC 6502 shutdown nosave > /dev/null 2>&1; wait
