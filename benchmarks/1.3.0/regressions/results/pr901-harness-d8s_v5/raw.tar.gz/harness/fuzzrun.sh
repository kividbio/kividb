#!/usr/bin/env bash
# fuzzrun.sh <candidate-binary> <n> <seeds...>
B=$1; N=$2; shift 2
cd ~/w && mkdir -p res/fuzz && cd res/fuzz
mkdir -p d1 d2 d3; ${REF:-$HOME/w/tmaster/release/kividb} --dir d1 --port 6390 --threads 2 --loglevel warning > m.log 2>&1 & P1=$!
$B --dir d2 --port 6391 --threads 2 --loglevel warning > b.log 2>&1 & P2=$!
/opt/redis-8.10.2/src/redis-server --dir d3 --port 6392 --save '' --appendonly no > r.log 2>&1 & P3=$!
sleep 1.5
for s in "$@"; do python3 ~/w/fuzz901.py $N $s master=6390 branch=6391 redis=6392; mkdir -p s$s; mv fuzz-mismatch-*.txt s$s/; done
kill $P1 $P2 $P3; wait
