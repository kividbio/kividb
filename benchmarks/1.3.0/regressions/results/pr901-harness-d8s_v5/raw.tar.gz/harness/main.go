// lg: load generator for the Tyk (#901) breakdown.
// Synthetic clock: every call takes the next timestamp of a global counter
// (start + n*dt ns), so each key's sorted-set window holds about
// per*1e9/dt/keys members whatever the throughput (dt 83333 ns, 5000 keys,
// per 60 -> ~144, as Tyk's real run at ~12k req/s with rate 1000 per 60).
package main

import (
	sha1pkg "crypto/sha1"
	"context"
	"flag"
	"fmt"
	"math/rand"
	"os"
	"sort"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/redis/go-redis/v9"
)

const tykScript = `local key = KEYS[1]

local now_str = ARGV[1]
local window_start_str = ARGV[2]
local max_allowed = tonumber(ARGV[3])
local per_seconds = tonumber(ARGV[4])

redis.call("ZREMRANGEBYSCORE", key, "-inf", window_start_str)

local count = redis.call("ZCARD", key)

redis.call("ZADD", key, now_str, now_str)
redis.call("EXPIRE", key, per_seconds)

local remaining = max_allowed - count - 1
if remaining < 0 then
	remaining = 0
end

local earliest_next = now_str
if count >= max_allowed then
	local oldest = redis.call("ZRANGE", key, -max_allowed, -max_allowed)
	if #oldest > 0 then
		earliest_next = oldest[1]
	end
end

return { count, remaining, earliest_next }
`

const ret1Script = `return 1`

const cadScript = `if redis.call("get",KEYS[1]) == ARGV[1] then return redis.call("del",KEYS[1]) else return 0 end`

// centrifuge v0.40.1 broker_history_list.lua / broker_history_add_list.lua (MIT), as in suite 25.
const cfHistScript = `local list_key = KEYS[1]
local meta_key = KEYS[2]
local include_publications = ARGV[1]
local list_right_bound = ARGV[2]
local meta_expire = ARGV[3]
local new_epoch_if_empty = ARGV[4]

local stream_meta = redis.call("hmget", meta_key, "e", "s")
local current_epoch, top_offset = stream_meta[1], stream_meta[2]

if current_epoch == false then
    current_epoch = new_epoch_if_empty
    top_offset = 0
    redis.call("hset", meta_key, "e", current_epoch)
end

if top_offset == false then
    top_offset = 0
end

if meta_expire ~= '0' then
    redis.call("expire", meta_key, meta_expire)
end

local pubs = nil
if include_publications ~= "0" then
    pubs = redis.call("lrange", list_key, 0, list_right_bound)
end

return { top_offset, current_epoch, pubs }
`

const cfAddScript = `local list_key = KEYS[1]
local meta_key = KEYS[2]
local result_key = KEYS[3]
local message_payload = ARGV[1]
local ltrim_right_bound = ARGV[2]
local list_ttl = ARGV[3]
local channel = ARGV[4]
local meta_expire = ARGV[5]
local new_epoch_if_empty = ARGV[6]
local publish_command = ARGV[7]
local result_key_expire = ARGV[8]
local use_delta = ARGV[9]

if result_key_expire ~= '' then
    local cached_result = redis.call("hmget", result_key, "e", "s")
    local result_epoch, result_offset = cached_result[1], cached_result[2]
    if result_epoch ~= false then
        return { result_offset, result_epoch, "1" }
    end
end

local current_epoch = redis.call("hget", meta_key, "e")
if current_epoch == false then
    current_epoch = new_epoch_if_empty
    redis.call("hset", meta_key, "e", current_epoch)
end

local top_offset = redis.call("hincrby", meta_key, "s", 1)

if meta_expire ~= '0' then
    redis.call("expire", meta_key, meta_expire)
end

local prev_message_payload = ""
if use_delta == "1" then
    prev_message_payload = redis.call("lindex", list_key, 0) or ""
end

local payload = "__" .. "p1:" .. top_offset .. ":" .. current_epoch .. "__" .. message_payload
redis.call("lpush", list_key, payload)
redis.call("ltrim", list_key, 0, ltrim_right_bound)
redis.call("expire", list_key, list_ttl)

if channel ~= '' then
    if use_delta == "1" then
        payload = "__" ..
        "d1:" ..
        top_offset ..
        ":" ..
        current_epoch ..
        ":" .. #prev_message_payload .. ":" .. prev_message_payload .. ":" .. #message_payload .. ":" .. message_payload
    end
    redis.call(publish_command, channel, payload)
end

if result_key_expire ~= '' then
    redis.call("hset", result_key, "e", current_epoch, "s", top_offset)
    redis.call("expire", result_key, result_key_expire)
end

return { top_offset, current_epoch, "0" }
`

var shas = map[string]string{}

func shaOf(s string) string { return fmt.Sprintf("%x", sha1pkg.Sum([]byte(s))) }

func cfKeys() (string, string) {
	if *tag {
		return "cf.list.{ch}", "cf.list.meta.{ch}"
	}
	return "cf.list.ch", "cf.list.meta.ch"
}

var (
	addr   = flag.String("addr", "127.0.0.1:6379", "")
	conns  = flag.Int("c", 64, "connections (one goroutine each)")
	dur    = flag.Duration("d", 20*time.Second, "")
	warm   = flag.Duration("w", 3*time.Second, "")
	mode   = flag.String("mode", "script", "script|seq4|zrem|zcard|zadd|expire|default|incr|preload|emit")
	keys   = flag.Int("keys", 5000, "")
	tag    = flag.Bool("tag", false, "wrap key in {}")
	per    = flag.Int64("per", 60, "")
	dt     = flag.Int64("dt", 83333, "ns per call on the synthetic clock")
	pid    = flag.Int("pid", 0, "server pid for CPU accounting")
	nEmit  = flag.Int("n", 100000, "emit: ops")
	emitW  = flag.Int("emitwarm", 0, "emit: ops before (written first, to <out>-warm)")
	out    = flag.String("out", "", "emit file")
	maxAll = flag.Int64("max", 1000, "")
	clockF = flag.String("clockfile", "", "keep the synthetic clock across runs")
)

var clock int64
var base = time.Now().UnixNano()

func hx(i int) string { return fmt.Sprintf("%016x", uint64(i)*0x9E3779B97F4A7C15) }

func key(i int) string {
	if *tag {
		return "rate-limit-{" + hx(i) + "}"
	}
	return "rate-limit-" + hx(i)
}

var getFrac = flag.Float64("getfrac", 0.44, "tyk modes: share of requests that start with GET apikey (0.44 in the real 5000-key run)")
var sessVal = `{"allowance":1000,"rate":1000,"per":60,"date_created":"2026-11-18T16:05:58.604712749Z","expires":-1,"quota_max":100000000,"quota_renews":1795021561,"quota_remaining":99999863,"quota_renewal_rate":3600,"access_rights":{"bench":{"api_name":"bench","api_id":"bench","versions":["Default"]}},"org_id":"default","oauth_client_id":"","basic_auth_data":{"password":"","hash_type":""},"jwt_data":{"secret":""},"hmac_enabled":false,"hmac_string":""}`
var pubVal = `{"command":"KeySpaceUpdateNotification","payload":"b656f3424075c5c0","signature":"8f8a6667c15288f5515b665018380b011517e3d52efa1bf84063299d29cdcb39","algorithm":5}`

func cpuTicks(p int) int64 {
	if p == 0 {
		return 0
	}
	b, err := os.ReadFile(fmt.Sprintf("/proc/%d/stat", p))
	if err != nil {
		return 0
	}
	s := string(b)
	f := strings.Fields(s[strings.LastIndex(s, ")")+2:])
	u, _ := strconv.ParseInt(f[11], 10, 64)
	st, _ := strconv.ParseInt(f[12], 10, 64)
	return u + st
}

// ops returns the commands of one call as argument lists.
func opCmds(r *rand.Rand, sha string) [][]interface{} {
	i := r.Intn(*keys)
	n := base + atomic.AddInt64(&clock, 1)**dt
	ns := strconv.FormatInt(n, 10)
	ws := strconv.FormatInt(n-*per*1e9, 10)
	k := key(i)
	switch *mode {
	case "ret1":
		if *tag {
			return [][]interface{}{{"EVALSHA", shaOf(ret1Script), "1", "{" + hx(i) + "}"}}
		}
		return [][]interface{}{{"EVALSHA", shaOf(ret1Script), "0"}}
	case "cad":
		lk := "lock:" + hx(i)
		if *tag {
			lk = "lock:{" + hx(i) + "}"
		}
		tok := hx(i + 7)
		return [][]interface{}{{"SET", lk, tok, "PX", "30000"}, {"EVALSHA", shaOf(cadScript), "1", lk, tok}}
	case "lockset":
		lk := "lock:" + hx(i)
		if *tag {
			lk = "lock:{" + hx(i) + "}"
		}
		return [][]interface{}{{"SET", lk, hx(i + 7), "PX", "30000"}}
	case "cfhist":
		l, m := cfKeys()
		return [][]interface{}{{"EVALSHA", shaOf(cfHistScript), "2", l, m, "1", "-1", "0", "abcd"}}
	case "cfadd":
		l, m := cfKeys()
		return [][]interface{}{{"EVALSHA", shaOf(cfAddScript), "3", l, m, "", `{"bench": true}`, "99", "100", "cf.client.ch", "0", "abcd", "publish", "", "0"}}
	case "script":
		return [][]interface{}{{"EVALSHA", sha, "1", k, ns, ws, *maxAll, *per}}
	case "seq4":
		return [][]interface{}{{"ZREMRANGEBYSCORE", k, "-inf", ws}, {"ZCARD", k}, {"ZADD", k, ns, ns}, {"EXPIRE", k, *per}}
	case "zrem":
		// trim and re-add so the window stays put: only the ZREMRANGEBYSCORE is timed? no: both are sent; see zadd.
		return [][]interface{}{{"ZREMRANGEBYSCORE", k, "-inf", ws}}
	case "zcard":
		return [][]interface{}{{"ZCARD", k}}
	case "zadd":
		return [][]interface{}{{"ZADD", k, ns, ns}}
	case "expire":
		return [][]interface{}{{"EXPIRE", k, *per}}
	case "incr":
		return [][]interface{}{{"INCR", "quota-" + hx(i)}}
	case "tykroll", "tykdef":
		var c [][]interface{}
		if r.Float64() < *getFrac {
			c = append(c, []interface{}{"GET", "apikey-" + hx(i)})
		}
		if *mode == "tykroll" {
			c = append(c, []interface{}{"EVALSHA", sha, "1", k, ns, ws, *maxAll, *per})
		}
		return append(c, []interface{}{"PTTL", "quota-" + hx(i)}, []interface{}{"INCR", "quota-" + hx(i)},
			[]interface{}{"SET", "apikey-" + hx(i), sessVal}, []interface{}{"PUBLISH", "tyk.cluster.notifications", pubVal})
	case "get":
		return [][]interface{}{{"GET", "apikey-" + hx(i)}}
	case "pttl":
		return [][]interface{}{{"PTTL", "quota-" + hx(i)}}
	case "set":
		return [][]interface{}{{"SET", "apikey-" + hx(i), sessVal}}
	case "publish":
		return [][]interface{}{{"PUBLISH", "tyk.cluster.notifications", pubVal}}
	case "default":
		v := strings.Repeat("x", 300)
		return [][]interface{}{{"PTTL", "quota-" + strconv.Itoa(i)}, {"INCR", "quota-" + strconv.Itoa(i)},
			{"SET", "apikey-" + strconv.Itoa(i), v}, {"PUBLISH", "tyk.cluster.notifications", "x"}}
	}
	panic("mode")
}

func resp(w *strings.Builder, args []interface{}) {
	fmt.Fprintf(w, "*%d\r\n", len(args))
	for _, a := range args {
		s := fmt.Sprint(a)
		fmt.Fprintf(w, "$%d\r\n%s\r\n", len(s), s)
	}
}

func main() {
	flag.Parse()
	ctx := context.Background()
	if *clockF != "" && *mode != "preload" {
		if b, err := os.ReadFile(*clockF); err == nil {
			if v, err := strconv.ParseInt(strings.TrimSpace(string(b)), 10, 64); err == nil {
				base = v
			}
		}
	}
	defer func() {
		if *clockF != "" {
			os.WriteFile(*clockF, []byte(strconv.FormatInt(base+atomic.LoadInt64(&clock)**dt, 10)), 0o644)
		}
	}()
	sha := ""
	if *mode != "emit" {
		c := redis.NewClient(&redis.Options{Addr: *addr})
		var err error
		sha, err = c.ScriptLoad(ctx, tykScript).Result()
		if err != nil {
			fmt.Println("script load:", err)
		}
		for _, src := range []string{ret1Script, cadScript, cfHistScript, cfAddScript} {
			if _, err := c.ScriptLoad(ctx, src).Result(); err != nil {
				fmt.Println("script load:", err)
			}
		}
		if *mode == "cfhist" {
			l, m := cfKeys()
			c.Del(ctx, l, m)
			for j := 0; j < 4; j++ {
				c.Do(ctx, "EVALSHA", shaOf(cfAddScript), "3", l, m, "", "{}", 3, 300, "", 0, "abcd", "publish", "", 0)
			}
		}
		c.Close()
	}
	if *mode == "preload" || *mode == "emit" {
		// window members for every key, ending at the clock's start
		members := *per * 1e9 / *dt / int64(*keys)
		if *mode == "preload" {
			c := redis.NewClient(&redis.Options{Addr: *addr})
			for i := 0; i < *keys; i++ {
				p := c.Pipeline()
				p.Del(ctx, key(i))
				for m := int64(0); m < members; m++ {
					t := base - *per*1e9 + (m*int64(*keys)+int64(i))**dt
					p.ZAdd(ctx, key(i), redis.Z{Score: float64(t), Member: strconv.FormatInt(t, 10)})
				}
				p.Expire(ctx, key(i), time.Duration(*per)*time.Second)
				p.Set(ctx, "apikey-"+hx(i), sessVal, 0)
				p.Set(ctx, "quota-"+hx(i), "1", 0)
				if _, err := p.Exec(ctx); err != nil {
					fmt.Println(err)
					os.Exit(1)
				}
			}
			n, _ := c.ZCard(ctx, key(0)).Result()
			fmt.Printf("preloaded %d keys, %d members each (key0 zcard %d), sha %s\n", *keys, members, n, sha)
			return
		}
		// emit: a RESP file: SCRIPT LOAD, the preload, <emitwarm> ops to <out>-warm, then n ops to <out>
		realMode := os.Getenv("EMITMODE")
		*mode = realMode
		r := rand.New(rand.NewSource(1))
		var w strings.Builder
		resp(&w, []interface{}{"SCRIPT", "LOAD", tykScript})
		for _, src := range []string{ret1Script, cadScript, cfHistScript, cfAddScript} {
			resp(&w, []interface{}{"SCRIPT", "LOAD", src})
		}
		if realMode == "cfhist" {
			l, m := cfKeys()
			for j := 0; j < 4; j++ {
				resp(&w, []interface{}{"EVALSHA", shaOf(cfAddScript), "3", l, m, "", "{}", 3, 300, "", 0, "abcd", "publish", "", 0})
			}
		}
		tykPre := realMode == "script" || realMode == "seq4" || strings.HasPrefix(realMode, "tyk") || realMode == "default"
		for i := 0; tykPre && i < *keys; i++ {
			for m := int64(0); m < members; m++ {
				t := base - *per*1e9 + (m*int64(*keys)+int64(i))**dt
				resp(&w, []interface{}{"ZADD", key(i), t, t})
			}
			if strings.HasPrefix(realMode, "default") || realMode == "incr" {
				resp(&w, []interface{}{"SET", "quota-" + strconv.Itoa(i), "1"})
			}
		}
		sha1 := fmt.Sprintf("%x", sha1pkg.Sum([]byte(tykScript)))
		for i := 0; i < *emitW; i++ {
			for _, a := range opCmds(r, sha1) {
				resp(&w, a)
			}
		}
		os.WriteFile(*out+"-warm", []byte(w.String()), 0o644)
		w.Reset()
		cnt := 0
		for i := 0; i < *nEmit; i++ {
			for _, a := range opCmds(r, sha1) {
				resp(&w, a)
				cnt++
			}
		}
		os.WriteFile(*out, []byte(w.String()), 0o644)
		fmt.Printf("emitted %d commands\n", cnt)
		return
	}

	c := redis.NewClient(&redis.Options{Addr: *addr, PoolSize: *conns, MinIdleConns: *conns, ReadTimeout: 30 * time.Second, WriteTimeout: 30 * time.Second})
	var stop, measuring atomic.Bool
	var ops atomic.Int64
	lats := make([][]time.Duration, *conns)
	var errs atomic.Int64
	var wg sync.WaitGroup
	for g := 0; g < *conns; g++ {
		wg.Add(1)
		go func(g int) {
			defer wg.Done()
			r := rand.New(rand.NewSource(int64(g) + time.Now().UnixNano()))
			for !stop.Load() {
				t0 := time.Now()
				for _, a := range opCmds(r, sha) {
					if err := c.Do(ctx, a...).Err(); err != nil && err != redis.Nil {
						if errs.Add(1) < 3 {
							fmt.Println("err:", err)
						}
					}
				}
				if measuring.Load() {
					lats[g] = append(lats[g], time.Since(t0))
					ops.Add(1)
				}
			}
		}(g)
	}
	time.Sleep(*warm)
	t0 := cpuTicks(*pid)
	m0 := cpuTicks(os.Getpid())
	start := time.Now()
	measuring.Store(true)
	time.Sleep(*dur)
	measuring.Store(false)
	el := time.Since(start)
	t1 := cpuTicks(*pid)
	m1 := cpuTicks(os.Getpid())
	stop.Store(true)
	wg.Wait()
	var all []time.Duration
	for _, l := range lats {
		all = append(all, l...)
	}
	sort.Slice(all, func(i, j int) bool { return all[i] < all[j] })
	q := func(f float64) float64 {
		if len(all) == 0 {
			return 0
		}
		return float64(all[int(f*float64(len(all)-1))].Microseconds()) / 1000
	}
	n := ops.Load()
	rps := float64(n) / el.Seconds()
	cpu := float64(t1-t0) * 10000 / float64(n) // us of server CPU per call (100 Hz ticks)
	fmt.Printf("mode=%s tag=%v c=%d ops/s=%.0f p50=%.2fms p99=%.2fms srvCPU=%.2fus/op srvCores=%.2f cliCores=%.2f errs=%d\n",
		*mode, *tag, *conns, rps, q(0.5), q(0.99), cpu, float64(t1-t0)/100/el.Seconds(), float64(m1-m0)/100/el.Seconds(), errs.Load())
}
