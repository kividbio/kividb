# dig.py <port>: a digest of the whole dataset (KiviDB has no DEBUG DIGEST):
# every key of databases 0-15 with its DEBUG DIGEST-VALUE and PEXPIRETIME.
import hashlib, redis, sys
h = hashlib.sha1(); n = 0
for db in range(16):
    r = redis.Redis(port=int(sys.argv[1]), db=db)
    keys = sorted(r.scan_iter(count=1000))
    for k in keys:
        d = r.execute_command("DEBUG", "DIGEST-VALUE", k)
        t = r.pexpiretime(k)
        h.update(b"%d|%s|%r|%d\n" % (db, k, d, t)); n += 1
print("%s keys=%d" % (h.hexdigest(), n))
