#!/usr/bin/env bash
# The script-runner hand-off: per-thread CPU of one server over a run.
#   hop.sh <label> <binary> <threads> <mode> <conns> [-tag]
set -u
L=$1; BIN=$2; T=$3; M=$4; C=$5; TG=${6:-}
OUT=~/w/res/hop; mkdir -p $OUT
RC="redis-cli -p 6379"
taskset -c 0,1 $BIN --port 6379 --threads $T --loglevel warning > $OUT/$L-server.log 2>&1 &
SP=$!
for _ in $(seq 100); do $RC ping 2>/dev/null | grep -q PONG && break; sleep 0.1; done
snap() { for t in /proc/$SP/task/*; do echo "$(basename $t):$(cat $t/comm | tr ' ' _) $(awk '{print $14+$15}' $t/stat)"; done | sort; }
$RC flushall > /dev/null
[ $M = script ] && { rm -f /tmp/lgclock; taskset -c 2-7 ~/w/bin/sb -mode preload $TG -clockfile /tmp/lgclock > /dev/null; }
# warm (promotes the script to the inline path) then measure
taskset -c 2-7 ~/w/bin/sb -mode $M $TG -c $C -d 2s -w 1s -clockfile /tmp/lgclock > /dev/null
$RC config resetstat > /dev/null
snap > /tmp/hop0
r=$(taskset -c 2-7 ~/w/bin/sb -mode $M $TG -c $C -d 10s -w 0s -pid $SP -clockfile /tmp/lgclock)
snap > /tmp/hop1
calls=$($RC info commandstats | tr -d '\r' | grep '^cmdstat_evalsha:' | sed 's/^cmdstat_evalsha:calls=\([0-9]*\),.*/\1/')
hand=$($RC info stats | tr -d '\r' | grep '^scripts_handed_to_runner:' | cut -d: -f2)
per=$(join /tmp/hop0 /tmp/hop1 | awk -v n=$calls '{split($1,a,":"); d[a[2]]+=$3-$2} END {for (k in d) if (d[k]>0) printf "%s=%.2fus ", k, d[k]*10000/n}')
echo "$L t=$T $M$TG c=$C $r calls=$calls handed=$hand | per-thread CPU/call: $per" | tee -a $OUT/hop.txt
$RC shutdown nosave > /dev/null 2>&1; sleep 0.5; kill $SP 2>/dev/null; wait $SP 2>/dev/null
