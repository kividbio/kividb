#!/usr/bin/env bash
# Hot path on plain copies of the trees (worktrees do not resolve inside docker).
set -u
rm -rf ~/w/res/hot2; mkdir -p ~/w/res/hot2
for f in default lua,tls; do
  for m in uring tokio; do
    for t in hnm hbr; do
      fe=$f; [ $f = default ] && fe=
      tag=$t-${f/,/}
      (cd ~/w/$t && DNS=1 OFFLINE= MODEL=$m FEATURES=$fe EXEC=1 CMP=plain LTO=fat ONLY='^(GET|SET)-100$' \
        bash scripts/perf/run.sh $tag) > ~/w/res/hot2/$tag-$m.txt 2>&1
    done
  done
done
echo HOT2 > ~/w/res/hot2/done
